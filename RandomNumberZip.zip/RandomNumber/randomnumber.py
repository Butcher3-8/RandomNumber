import tkinter as tk
import random

def rastgele_cift_sayi():
    sayi = random.choice([i for i in range(0, 101, 2)])  
    sayi_goster(sayi)

def rastgele_tek_sayi():
    sayi = random.choice([i for i in range(1, 100, 2)])  
    sayi_goster(sayi)

def rastgele_sayi():
    sayi = random.randint(0, 100)  
    sayi_goster(sayi)

def sayi_goster(sayi):

    for widget in frame.winfo_children():
        widget.destroy()
    
    sayi_label = tk.Label(frame, text=str(sayi), font=("Arial", 24))
    sayi_label.pack()

pencere = tk.Tk()
pencere.title("RANDOM NUMBER")


frame = tk.Frame(pencere)
frame.pack(pady=20)

cift_buton = tk.Button(frame, text="Random Double Number", command=rastgele_cift_sayi)
cift_buton.pack(pady=5)

tek_buton = tk.Button(frame, text="Random Odd Number", command=rastgele_tek_sayi)
tek_buton.pack(pady=5)

rastgele_buton = tk.Button(frame, text="Random Number", command=rastgele_sayi)
rastgele_buton.pack(pady=5)


pencere.mainloop()
